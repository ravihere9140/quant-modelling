"""
main.py
--------
End-to-end pipeline: simulate data -> engineer features -> walk-forward
train/evaluate models -> backtest -> save plots + summary tables.

Run with:  python3 main.py
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from data_simulation import simulate_market
from features import build_features
from model import evaluate_models, fit_full_model_for_importance
from backtest import build_portfolio, benchmark_equal_weight, performance_stats

plt.rcParams.update({
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "axes.grid": True,
    "grid.alpha": 0.25,
    "font.size": 11,
})


def main():
    print("1/5  Simulating market data ...")
    raw = simulate_market()
    raw.to_parquet("outputs/market_data.parquet", index=False)

    print("2/5  Engineering features ...")
    feat, feature_cols = build_features(raw)
    feat.to_parquet("outputs/features.parquet", index=False)

    print("3/5  Walk-forward training & evaluating models (this takes a couple of minutes) ...")
    summary, oos = evaluate_models(feat, feature_cols, n_splits=5)
    oos.to_parquet("outputs/oos_predictions.parquet", index=False)
    summary.to_csv("outputs/model_comparison.csv")
    importance = fit_full_model_for_importance(feat, feature_cols)
    importance.to_csv("outputs/feature_importance.csv")

    print("4/5  Backtesting long/short portfolio ...")
    best_model = summary["mean_IC"].idxmax()
    pred_col = f"pred_{best_model}"
    pnl = build_portfolio(oos, pred_col=pred_col, cost_bps=5.0)
    bm = benchmark_equal_weight(oos)
    strat_stats = performance_stats(pnl["net_ret_daily_eq"])
    bm_stats = performance_stats(bm)
    stats_df = pd.DataFrame({"ML Long/Short Strategy": strat_stats, "Equal-Weight Benchmark": bm_stats})
    stats_df.to_csv("outputs/performance_summary.csv")

    print("5/5  Rendering charts ...")

    # --- Equity curve -----------------------------------------------
    equity_strat = (1 + pnl["net_ret_daily_eq"]).cumprod()
    equity_bm = (1 + bm.reindex(pnl.index)).cumprod()
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.plot(equity_strat.index, equity_strat.values, label=f"ML Long/Short ({best_model})", lw=2, color="#1f6feb")
    ax.plot(equity_bm.index, equity_bm.values, label="Equal-Weight Benchmark", lw=1.5, color="#8b949e", ls="--")
    ax.set_title("Cumulative Growth of $1 — Strategy vs. Benchmark (net of costs)")
    ax.set_ylabel("Equity ($)")
    ax.legend()
    fig.tight_layout()
    fig.savefig("outputs/equity_curve.png", dpi=140)
    plt.close(fig)

    # --- Drawdown ------------------------------------------------------
    running_max = equity_strat.cummax()
    dd = equity_strat / running_max - 1
    fig, ax = plt.subplots(figsize=(9, 3.2))
    ax.fill_between(dd.index, dd.values, 0, color="#d1242f", alpha=0.5)
    ax.set_title("Strategy Drawdown")
    ax.set_ylabel("Drawdown")
    fig.tight_layout()
    fig.savefig("outputs/drawdown.png", dpi=140)
    plt.close(fig)

    # --- Feature importance ---------------------------------------------
    fig, ax = plt.subplots(figsize=(7, 4.5))
    importance.sort_values().plot(kind="barh", ax=ax, color="#1f6feb")
    ax.set_title("Feature Importance — Gradient Boosting Model")
    ax.set_xlabel("Relative Importance")
    fig.tight_layout()
    fig.savefig("outputs/feature_importance.png", dpi=140)
    plt.close(fig)

    # --- Model comparison (IC) ---------------------------------------
    fig, ax = plt.subplots(figsize=(6.5, 4))
    summary["mean_IC"].plot(kind="bar", ax=ax, color=["#8b949e", "#1f6feb", "#238636"])
    ax.axhline(0, color="black", lw=0.8)
    ax.set_title("Mean Out-of-Sample Information Coefficient by Model")
    ax.set_ylabel("Spearman IC")
    plt.xticks(rotation=20)
    fig.tight_layout()
    fig.savefig("outputs/model_ic_comparison.png", dpi=140)
    plt.close(fig)

    # --- Rolling IC over time (signal stability) ------------------------
    df_ic = oos.copy()
    df_ic["y_rank"] = df_ic.groupby("date")[f"fwd_ret"].rank()
    df_ic["p_rank"] = df_ic.groupby("date")[pred_col].rank()
    daily_ic = df_ic.groupby("date").apply(lambda g: np.corrcoef(g["y_rank"], g["p_rank"])[0, 1])
    rolling_ic = daily_ic.rolling(21).mean()
    fig, ax = plt.subplots(figsize=(9, 3.5))
    ax.plot(rolling_ic.index, rolling_ic.values, color="#8957e5")
    ax.axhline(0, color="black", lw=0.8)
    ax.set_title("21-Day Rolling Information Coefficient (signal stability)")
    fig.tight_layout()
    fig.savefig("outputs/rolling_ic.png", dpi=140)
    plt.close(fig)

    print("\n=== Model comparison (walk-forward mean IC / IC-IR) ===")
    print(summary.round(4))
    print(f"\nBest model: {best_model}")
    print("\n=== Strategy performance ===")
    print(stats_df.round(4))
    print("\nAll outputs saved to outputs/")


if __name__ == "__main__":
    main()
