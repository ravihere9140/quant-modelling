"""
features.py
------------
Turns raw OHLCV panel data into a cross-sectional feature matrix.

Feature families (all standard building blocks of systematic equity
strategies):
    - multi-horizon momentum / reversal returns
    - realised volatility
    - RSI-style overbought/oversold oscillator
    - moving-average crossover (trend)
    - volume shock (liquidity / participation)
    - cross-sectional z-scores (rank each feature vs. the universe on a
      given day, since cross-sectional strategies care about RELATIVE
      not absolute levels)

Target: forward 5-day return (regression target), used both as a
continuous label and, after cross-sectional ranking, to build long/short
decile portfolios in the backtester.
"""

import numpy as np
import pandas as pd


def _rsi(series: pd.Series, window: int = 14) -> pd.Series:
    delta = series.diff()
    gain = delta.clip(lower=0).rolling(window).mean()
    loss = (-delta.clip(upper=0)).rolling(window).mean()
    rs = gain / loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))


def build_features(df: pd.DataFrame, horizon: int = 5) -> pd.DataFrame:
    df = df.sort_values(["asset", "date"]).copy()
    out = []

    for asset, g in df.groupby("asset", sort=False):
        g = g.set_index("date").copy()
        ret1 = g["close"].pct_change()

        g["mom_5"] = g["close"].pct_change(5)
        g["mom_10"] = g["close"].pct_change(10)
        g["mom_21"] = g["close"].pct_change(21)
        g["rev_1"] = -ret1                              # 1-day reversal
        g["vol_10"] = ret1.rolling(10).std()
        g["vol_21"] = ret1.rolling(21).std()
        g["rsi_14"] = _rsi(g["close"], 14)
        g["ma_gap"] = g["close"] / g["close"].rolling(20).mean() - 1
        g["hl_spread"] = (g["high"] - g["low"]) / g["close"]
        g["vol_shock"] = g["volume"] / g["volume"].rolling(21).mean() - 1

        # forward-looking label: NEXT `horizon`-day return (shifted back)
        g["fwd_ret"] = g["close"].shift(-horizon) / g["close"] - 1

        g["asset"] = asset
        out.append(g.reset_index())

    feat = pd.concat(out, ignore_index=True)

    feature_cols = [
        "mom_5", "mom_10", "mom_21", "rev_1", "vol_10", "vol_21",
        "rsi_14", "ma_gap", "hl_spread", "vol_shock",
    ]

    # cross-sectional z-score each feature, per day, per sector-neutral
    # basis is a common refinement but we keep it universe-relative here
    def _zscore(x):
        return (x - x.mean()) / (x.std(ddof=0) + 1e-9)

    for c in feature_cols:
        feat[f"{c}_z"] = feat.groupby("date")[c].transform(_zscore)

    z_cols = [f"{c}_z" for c in feature_cols]
    feat = feat.dropna(subset=z_cols + ["fwd_ret"]).reset_index(drop=True)

    return feat, z_cols


if __name__ == "__main__":
    raw = pd.read_parquet("outputs/market_data.parquet")
    feat, cols = build_features(raw)
    feat.to_parquet("outputs/features.parquet", index=False)
    print(feat[["date", "asset"] + cols + ["fwd_ret"]].head())
    print(f"\nFeature matrix: {feat.shape[0]:,} rows x {len(cols)} features")
