"""
backtest.py
------------
Converts out-of-sample model predictions into a tradeable long/short
cross-sectional portfolio and evaluates it the way a systematic desk
would before ever considering production:

    - each day, rank assets by predicted forward return
    - go long the top decile, short the bottom decile, dollar-neutral,
      equal-weighted within each leg
    - charge a transaction cost on turnover (in bps) to see whether the
      signal survives realistic frictions
    - report annualised return, volatility, Sharpe, Sortino, max
      drawdown, hit rate, turnover, and a benchmark (equal-weight
      long-only on the whole universe) for comparison
"""

import numpy as np
import pandas as pd


TRADING_DAYS = 252


def build_portfolio(oos: pd.DataFrame, pred_col: str, decile: float = 0.1,
                     cost_bps: float = 5.0, horizon: int = 5):
    """
    oos: columns [date, asset, fwd_ret, pred_col]
    fwd_ret is the *horizon*-day forward return already, so we convert the
    strategy's periodic (horizon-day) P&L into a daily-equivalent series by
    spreading it evenly, which keeps annualisation straightforward and is a
    standard simplification for a research-stage backtest.
    """
    df = oos.copy()
    daily_pnl = []
    turnover_series = []
    prev_long, prev_short = set(), set()

    for date, g in df.groupby("date", sort=True):
        g = g.sort_values(pred_col)
        n = len(g)
        k = max(1, int(n * decile))

        shorts = g.iloc[:k]
        longs = g.iloc[-k:]

        long_ret = longs["fwd_ret"].mean()
        short_ret = shorts["fwd_ret"].mean()
        gross_ret = 0.5 * long_ret - 0.5 * short_ret   # dollar-neutral

        cur_long, cur_short = set(longs["asset"]), set(shorts["asset"])
        changed = len(cur_long - prev_long) + len(cur_short - prev_short)
        turnover = changed / (2 * k)
        cost = turnover * (cost_bps / 1e4)

        net_ret = gross_ret - cost
        daily_pnl.append((date, gross_ret, net_ret))
        turnover_series.append(turnover)
        prev_long, prev_short = cur_long, cur_short

    pnl = pd.DataFrame(daily_pnl, columns=["date", "gross_ret", "net_ret"]).set_index("date")
    # spread each `horizon`-day return over `horizon` trading days (approx.)
    pnl["net_ret_daily_eq"] = pnl["net_ret"] / horizon
    pnl["turnover"] = turnover_series
    return pnl


def benchmark_equal_weight(oos: pd.DataFrame, horizon: int = 5):
    bm = oos.groupby("date")["fwd_ret"].mean() / horizon
    return bm.rename("benchmark_daily_eq")


def performance_stats(daily_ret: pd.Series) -> dict:
    ann_ret = daily_ret.mean() * TRADING_DAYS
    ann_vol = daily_ret.std() * np.sqrt(TRADING_DAYS)
    sharpe = ann_ret / (ann_vol + 1e-12)

    downside = daily_ret[daily_ret < 0]
    down_vol = downside.std() * np.sqrt(TRADING_DAYS)
    sortino = ann_ret / (down_vol + 1e-12)

    equity = (1 + daily_ret).cumprod()
    running_max = equity.cummax()
    drawdown = equity / running_max - 1
    max_dd = drawdown.min()

    hit_rate = (daily_ret > 0).mean()
    calmar = ann_ret / (abs(max_dd) + 1e-12)

    return {
        "Annualised Return": ann_ret,
        "Annualised Vol": ann_vol,
        "Sharpe": sharpe,
        "Sortino": sortino,
        "Max Drawdown": max_dd,
        "Calmar": calmar,
        "Daily Hit Rate": hit_rate,
    }


if __name__ == "__main__":
    oos = pd.read_parquet("outputs/oos_predictions.parquet")

    pnl = build_portfolio(oos, pred_col="pred_gradient_boosting", cost_bps=5.0)
    bm = benchmark_equal_weight(oos)

    strat_stats = performance_stats(pnl["net_ret_daily_eq"])
    bm_stats = performance_stats(bm)

    stats_df = pd.DataFrame({"ML Long/Short Strategy": strat_stats, "Equal-Weight Benchmark": bm_stats})
    print(stats_df.round(4))
    print(f"\nAverage daily turnover: {pnl['turnover'].mean():.2%}")

    stats_df.to_csv("outputs/performance_summary.csv")
    pnl.to_csv("outputs/strategy_pnl.csv")
    bm.to_csv("outputs/benchmark_pnl.csv")
