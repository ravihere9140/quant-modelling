# Cross-Sectional Equity Alpha: A Systematic ML Research Pipeline

A self-contained, end-to-end quantitative research project that mirrors the
core workflow of a systematic trading desk: **hypothesis → data → features →
model → rigorous backtest → risk-adjusted evaluation**. Built to demonstrate
the exact skill set called for in the Trexquant Quantitative Researcher role:
Python, machine learning, statistics/probability, and market understanding.

## The idea

Cross-sectional equity strategies don't try to predict *whether the market
goes up*; they try to predict *which stocks will do better than others* on a
given day, then go long the predicted winners and short the predicted
losers, dollar-neutral. This removes market direction as a source of risk
and isolates a stock-picking edge — hence the Sharpe ratio on the strategy
in this repo is much higher, and the drawdown much shallower, than a
long-only benchmark over the same period.

## Pipeline

| Stage | File | What it does |
|---|---|---|
| 1. Data | `data_simulation.py` | Simulates a 60-asset daily OHLCV universe with a market factor, sector factors, momentum & mean-reversion micro-structure, regime-switching volatility, and a weak, noisy latent alpha — i.e. a controlled environment where a *real but hard-to-find* edge exists, just like actual markets. No external data vendor or API key needed, so the project runs anywhere. |
| 2. Features | `features.py` | Builds 10 standard cross-sectional signals (multi-horizon momentum, 1-day reversal, realised vol, RSI, moving-average gap, volume shock) and cross-sectional z-scores each one per day, since what matters is relative not absolute positioning. |
| 3. Model | `model.py` | Trains Ridge, Random Forest, and Gradient Boosting regressors to predict forward 5-day returns, evaluated with **walk-forward (expanding window) validation** with a purge/embargo gap — never a random train/test split, which would leak future information. Scored on the **Information Coefficient** (daily cross-sectional Spearman rank correlation), the standard metric for alpha signals. |
| 4. Backtest | `backtest.py` | Converts predictions into a top/bottom-decile, dollar-neutral long/short portfolio, charges transaction costs on turnover, and reports Sharpe, Sortino, max drawdown, Calmar, hit rate — net of costs — against an equal-weight benchmark. |
| 5. Orchestration | `main.py` | Runs the full pipeline and saves all charts/tables to `outputs/`. |

## Why these design choices matter (and what they signal to a reviewer)

- **Walk-forward validation with embargo, not k-fold CV.** Random splits on
  time series leak information and produce wildly optimistic backtests —
  a classic mistake this project deliberately avoids.
- **Information Coefficient, not R² or accuracy.** Cross-sectional
  strategies only care about *ranking* assets correctly each day; IC
  (Spearman correlation of predicted vs. realised rank) is the metric
  the industry actually uses to grade a signal, along with its
  Information Ratio (IC mean / IC std) for stability.
- **Dollar-neutral long/short construction.** Isolates stock-selection
  skill from market beta — you can have genuine alpha even in a falling
  market, which is exactly what the benchmark comparison shows.
- **Costs are charged on realised turnover, not assumed away.** A signal
  that only looks good gross of costs isn't tradeable; this project
  reports both.
- **Everything is reproducible from a single `main.py` run** with no
  external dependencies beyond `pip install`-able packages — a reviewer
  can clone and run it in minutes.

## Results (this run)

See `outputs/performance_summary.csv` and `outputs/model_comparison.csv`
for exact numbers, and the charts below for the visual summary.

- `outputs/equity_curve.png` — cumulative $1 growth, strategy vs. benchmark
- `outputs/drawdown.png` — strategy drawdown over time
- `outputs/rolling_ic.png` — 21-day rolling Information Coefficient (signal stability)
- `outputs/model_ic_comparison.png` — Ridge vs. Random Forest vs. Gradient Boosting
- `outputs/feature_importance.png` — which signals the model relies on most

A representative run produces a long/short Sharpe ratio in the 1.5–2.5
range against a negative benchmark Sharpe over the same noisy window —
consistent with the simulated data containing a real but weak, realistic
edge rather than an inflated, over-fit one.

## Running it

```bash
pip install numpy pandas scikit-learn scipy matplotlib pyarrow
python3 main.py
```

Total runtime: ~2–3 minutes on a single core (walk-forward training across
3 models × 5 folds is the dominant cost).

## What would change for a production version

- Replace simulated data with a real market data vendor (this project's
  data layer is fully swappable — `build_features` just needs a dataframe
  with `date, asset, open, high, low, close, volume`).
- Add sector/beta-neutrality constraints and position/turnover limits to
  the portfolio construction step.
- Extend the feature set with alternative data and add hyperparameter
  search inside each walk-forward fold (kept simple here for clarity).
- Add a proper execution/slippage model rather than a flat bps assumption.

## Repository structure

```
trexquant_project/
├── data_simulation.py     # synthetic multi-asset market with factor structure
├── features.py             # cross-sectional feature engineering
├── model.py                 # walk-forward ML training & IC evaluation
├── backtest.py               # long/short portfolio construction & risk metrics
├── main.py                    # runs everything end-to-end, saves charts
├── README.md
└── outputs/                    # generated data, predictions, charts, tables
```
