"""
model.py
---------
Trains a model to predict cross-sectional forward returns and evaluates
it the way a quant research desk actually evaluates alpha signals:

    - walk-forward (expanding window) validation, NEVER a random
      train/test split, because random splits leak future information
      into the past in time-series problems
    - a purge/embargo gap between train and test folds equal to the
      label horizon, so that overlapping-return labels near the fold
      boundary can't leak
    - evaluation via the INFORMATION COEFFICIENT (Spearman rank
      correlation between predicted and realised forward returns),
      which is the standard metric for cross-sectional signals --
      R^2 / accuracy are not, because we only care about the RANKING
      of assets each day, not the absolute magnitude of returns
"""

import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import Ridge


def walk_forward_splits(dates: pd.Series, n_splits: int = 5, embargo_days: int = 5):
    """Yield (train_idx, test_idx) using an expanding window over unique dates."""
    unique_dates = np.sort(dates.unique())
    fold_size = len(unique_dates) // (n_splits + 1)

    for k in range(1, n_splits + 1):
        train_end = unique_dates[k * fold_size - 1]
        test_start_idx = k * fold_size + embargo_days
        test_end_idx = min((k + 1) * fold_size, len(unique_dates) - 1)
        if test_start_idx >= test_end_idx:
            continue
        test_start = unique_dates[test_start_idx]
        test_end = unique_dates[test_end_idx]

        train_mask = dates <= train_end
        test_mask = (dates > test_start) & (dates <= test_end)
        yield train_mask.values, test_mask.values


def information_coefficient(y_true: pd.Series, y_pred: np.ndarray, dates: pd.Series) -> pd.Series:
    """Daily cross-sectional Spearman IC, computed via rank-then-Pearson (fast, vectorized)."""
    tmp = pd.DataFrame({"date": dates.values, "y": y_true.values, "p": y_pred})
    tmp["y_rank"] = tmp.groupby("date")["y"].rank()
    tmp["p_rank"] = tmp.groupby("date")["p"].rank()

    def _corr(g):
        if len(g) < 6:
            return np.nan
        return np.corrcoef(g["y_rank"], g["p_rank"])[0, 1]

    ic = tmp.groupby("date", sort=False).apply(_corr)
    return ic.dropna()


MODELS = {
    "ridge": lambda: Ridge(alpha=5.0),
    "random_forest": lambda: RandomForestRegressor(
        n_estimators=120, max_depth=4, min_samples_leaf=300,
        max_features=0.6, n_jobs=-1, random_state=0,
    ),
    "gradient_boosting": lambda: GradientBoostingRegressor(
        n_estimators=120, max_depth=3, learning_rate=0.05,
        subsample=0.7, random_state=0,
    ),
}


def evaluate_models(feat: pd.DataFrame, feature_cols: list, n_splits: int = 5):
    results = {name: [] for name in MODELS}
    all_preds = []  # out-of-sample predictions, stitched together for the backtest

    for train_mask, test_mask in walk_forward_splits(feat["date"], n_splits=n_splits):
        X_train, y_train = feat.loc[train_mask, feature_cols], feat.loc[train_mask, "fwd_ret"]
        X_test, y_test = feat.loc[test_mask, feature_cols], feat.loc[test_mask, "fwd_ret"]
        dates_test = feat.loc[test_mask, "date"]

        fold_preds = {"date": feat.loc[test_mask, "date"].values,
                      "asset": feat.loc[test_mask, "asset"].values,
                      "fwd_ret": y_test.values}

        for name, ctor in MODELS.items():
            model = ctor()
            model.fit(X_train, y_train)
            pred = model.predict(X_test)
            ic = information_coefficient(y_test, pred, dates_test)
            results[name].append(ic.mean())
            fold_preds[f"pred_{name}"] = pred

        all_preds.append(pd.DataFrame(fold_preds))

    summary = pd.DataFrame({
        name: {"mean_IC": np.mean(v), "IC_IR": np.mean(v) / (np.std(v) + 1e-9)}
        for name, v in results.items()
    }).T

    oos = pd.concat(all_preds, ignore_index=True)
    return summary, oos


def fit_full_model_for_importance(feat: pd.DataFrame, feature_cols: list):
    """Fit gradient boosting on the full sample purely to inspect feature importance."""
    model = MODELS["gradient_boosting"]()
    model.fit(feat[feature_cols], feat["fwd_ret"])
    importance = pd.Series(model.feature_importances_, index=feature_cols).sort_values(ascending=False)
    return importance


if __name__ == "__main__":
    feat = pd.read_parquet("outputs/features.parquet")
    feature_cols = [c for c in feat.columns if c.endswith("_z")]

    summary, oos = evaluate_models(feat, feature_cols, n_splits=5)
    print("Walk-forward validation (mean daily Spearman IC, IC Information Ratio):")
    print(summary.round(4))

    oos.to_parquet("outputs/oos_predictions.parquet", index=False)

    importance = fit_full_model_for_importance(feat, feature_cols)
    print("\nFeature importance (gradient boosting):")
    print(importance.round(3))
    importance.to_csv("outputs/feature_importance.csv")
