"""
data_simulation.py
-------------------
Simulates daily OHLCV data for a cross-section of assets that mimics real
market micro-structure well enough to make the research problem non-trivial:

    - a common market factor (systematic risk)
    - sector factors (clusters of correlated assets)
    - an idiosyncratic momentum component (autocorrelated returns)
    - an idiosyncratic short-term mean-reversion component
    - stochastic (regime-switching) volatility
    - a slow-moving, PARTIALLY LEARNABLE alpha signal + a lot of noise,
      because real markets are mostly noise -- if the simulated alpha is
      too easy to recover, the ML step is meaningless.

This keeps the project self-contained (no external data vendor / API keys
needed) while still requiring genuine statistical modelling to extract
signal from noise, which is the core skill the role calls for.
"""

import numpy as np
import pandas as pd


def simulate_market(
    n_assets: int = 60,
    n_days: int = 1500,
    n_sectors: int = 6,
    seed: int = 42,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)

    dates = pd.bdate_range("2018-01-02", periods=n_days)
    sector_id = rng.integers(0, n_sectors, size=n_assets)

    # ---- regime-switching market volatility (2-state Markov chain) -------
    vol_states = np.array([0.008, 0.022])          # calm / stressed
    p_stay = np.array([0.985, 0.94])                # persistence
    state = 0
    market_vol = np.empty(n_days)
    for t in range(n_days):
        market_vol[t] = vol_states[state]
        if rng.random() > p_stay[state]:
            state = 1 - state

    market_ret = rng.normal(0.0003, 1.0, n_days) * market_vol

    # ---- sector factors ----------------------------------------------
    sector_ret = rng.normal(0.0, 0.006, size=(n_days, n_sectors))

    # ---- per-asset betas / loadings ------------------------------------
    mkt_beta = rng.normal(1.0, 0.3, n_assets).clip(0.2, 2.0)
    sector_beta = rng.normal(1.0, 0.25, n_assets).clip(0.2, 1.8)
    idio_vol = rng.uniform(0.01, 0.03, n_assets)

    # persistent latent "alpha" factor per asset: slow mean-reverting
    # process representing a real but weak and noisy predictable edge
    alpha_strength = rng.uniform(-1, 1, n_assets) * 0.00035

    records = []
    momentum_state = np.zeros(n_assets)   # AR(1) component
    mr_state = np.zeros(n_assets)          # short-term mean reversion state

    prices = np.full(n_assets, 100.0)

    for t, d in enumerate(dates):
        idio = rng.normal(0, 1, n_assets) * idio_vol

        # momentum: today's idio shock partly persists (AR(1), phi=0.05)
        momentum_state = 0.05 * momentum_state + idio

        # short-horizon mean reversion: shocks partially revert next day
        mr_component = -0.08 * mr_state
        mr_state = idio

        latent_alpha = alpha_strength * np.sin(t / 90.0 + rng.normal(0, 0.15, n_assets))

        asset_ret = (
            mkt_beta * market_ret[t]
            + sector_beta * sector_ret[t, sector_id]
            + 0.15 * momentum_state
            + mr_component
            + latent_alpha
            + idio
        )

        prices = prices * (1 + asset_ret)
        vol_intraday = idio_vol * rng.uniform(0.3, 0.6, n_assets)
        high = prices * (1 + np.abs(rng.normal(0, 1, n_assets)) * vol_intraday)
        low = prices * (1 - np.abs(rng.normal(0, 1, n_assets)) * vol_intraday)
        open_ = prices / (1 + asset_ret) * (1 + rng.normal(0, 0.001, n_assets))
        volume = rng.lognormal(mean=13.0, sigma=0.5, size=n_assets) * (
            1 + 3 * np.abs(asset_ret)
        )

        for i in range(n_assets):
            records.append(
                (d, f"AST_{i:03d}", sector_id[i], open_[i], high[i], low[i],
                 prices[i], volume[i])
            )

    df = pd.DataFrame(
        records,
        columns=["date", "asset", "sector", "open", "high", "low", "close", "volume"],
    )
    return df


if __name__ == "__main__":
    df = simulate_market()
    df.to_parquet("outputs/market_data.parquet", index=False)
    print(df.head())
    print(f"\nSimulated {df['asset'].nunique()} assets over "
          f"{df['date'].nunique()} trading days -> {len(df):,} rows")
